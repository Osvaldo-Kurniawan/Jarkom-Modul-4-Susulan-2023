#A4
route add -net 10.16.24.120 netmask 255.255.255.252 gw 10.16.24.118
#A5
route add -net 10.16.0.0 netmask 255.255.248.0 gw 10.16.24.118
#A6
route add -net 10.16.8.0 netmask 255.255.252.0 gw 10.16.24.118
#A7
route add -net 10.16.24.124 netmask 255.255.255.252 gw 10.16.24.118
#A8
route add -net 10.16.24.96 netmask 255.255.255.248 gw 10.16.24.118
