#A21
route add -net 10.16.16.0 netmask 255.255.252.0 gw 10.16.24.2
