#A20
route add -net 10.16.24.0 netmask 255.255.255.192 gw 10.16.24.150
#A21
route add -net 10.16.16.0 netmask 255.255.252.0 gw 10.16.24.150
