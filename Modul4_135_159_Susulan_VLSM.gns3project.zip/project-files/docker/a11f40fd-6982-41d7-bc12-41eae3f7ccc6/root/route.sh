#A5
route add -net 10.16.0.0 netmask 255.255.248.0 gw 10.16.24.122
#A8
route add -net 10.16.24.96 netmask 255.255.255.248 gw 10.16.24.126
