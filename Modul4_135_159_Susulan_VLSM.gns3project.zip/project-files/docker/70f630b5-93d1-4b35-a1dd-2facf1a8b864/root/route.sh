#A3
route add -net 10.16.24.116 netmask 255.255.255.252 gw 10.16.24.114
#A4
route add -net 10.16.24.120 netmask 255.255.255.252 gw 10.16.24.114
#A5
route add -net 10.16.0.0 netmask 255.255.248.0 gw 10.16.24.114
#A6
route add -net 10.16.8.0 netmask 255.255.252.0 gw 10.16.24.114
#A7
route add -net 10.16.24.124 netmask 255.255.255.252 gw 10.16.24.114
#A8
route add -net 10.16.24.96 netmask 255.255.255.248 gw 10.16.24.114
#A2
route add -net 10.16.26.64 netmask 255.255.255.224 gw 10.16.24.114

#A10
route add -net 10.16.22.0 netmask 255.255.255.0 gw 10.16.24.130

#A12
route add -net 10.16.24.104 netmask 255.255.255.248 gw 10.16.24.134
#A13
route add -net 10.16.24.136 netmask 255.255.255.252 gw 10.16.24.134
#A14
route add -net 10.16.24.140 netmask 255.255.255.252 gw 10.16.24.134
#A16
route add -net 10.16.12.0 netmask 255.255.252.0 gw 10.16.24.134
#A15
route add -net 10.16.23.0 netmask 255.255.255.0 gw 10.16.24.134
#A17
route add -net 10.16.24.144 netmask 255.255.255.252 gw 10.16.24.134
#A18
route add -net 10.16.20.0 netmask 255.255.254.0 gw 10.16.24.134
#A19
route add -net 10.16.24.148 netmask 255.255.255.252 gw 10.16.24.134
#A20
route add -net 10.16.24.0 netmask 255.255.255.192 gw 10.16.24.134
#A21
route add -net 10.16.16.0 netmask 255.255.252.0 gw 10.16.24.134
