#A16
route add -net 10.16.12.0 netmask 255.255.252.0 gw 10.16.24.142
#A15
route add -net 10.16.23.0 netmask 255.255.255.0 gw 10.16.24.142

#A19
route add -net 10.16.24.148 netmask 255.255.255.252 gw 10.16.24.146
#A18
route add -net 10.16.20.0 netmask 255.255.254.0 gw 10.16.24.146
#A20
route add -net 10.16.24.0 netmask 255.255.255.192 gw 10.16.24.146
#A21
route add -net 10.16.16.0 netmask 255.255.252.0 gw 10.16.24.146
